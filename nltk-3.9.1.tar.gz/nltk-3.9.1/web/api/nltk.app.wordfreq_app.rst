nltk.app.wordfreq\_app module
=============================

.. automodule:: nltk.app.wordfreq_app
   :members:
   :undoc-members:
   :show-inheritance:
