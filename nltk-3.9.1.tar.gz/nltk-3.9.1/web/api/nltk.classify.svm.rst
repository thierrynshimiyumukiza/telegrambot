nltk.classify.svm module
========================

.. automodule:: nltk.classify.svm
   :members:
   :undoc-members:
   :show-inheritance:
