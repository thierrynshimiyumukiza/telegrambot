nltk.corpus.reader.wordlist module
==================================

.. automodule:: nltk.corpus.reader.wordlist
   :members:
   :undoc-members:
   :show-inheritance:
