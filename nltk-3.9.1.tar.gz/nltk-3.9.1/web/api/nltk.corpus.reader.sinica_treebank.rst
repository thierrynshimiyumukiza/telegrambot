nltk.corpus.reader.sinica\_treebank module
==========================================

.. automodule:: nltk.corpus.reader.sinica_treebank
   :members:
   :undoc-members:
   :show-inheritance:
