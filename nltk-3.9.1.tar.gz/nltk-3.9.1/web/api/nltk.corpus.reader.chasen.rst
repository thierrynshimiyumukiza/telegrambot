nltk.corpus.reader.chasen module
================================

.. automodule:: nltk.corpus.reader.chasen
   :members:
   :undoc-members:
   :show-inheritance:
