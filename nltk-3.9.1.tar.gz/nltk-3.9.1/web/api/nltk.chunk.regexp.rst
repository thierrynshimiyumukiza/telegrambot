nltk.chunk.regexp module
========================

.. automodule:: nltk.chunk.regexp
   :members:
   :undoc-members:
   :show-inheritance:
