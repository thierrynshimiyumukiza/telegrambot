nltk.app.concordance\_app module
================================

.. automodule:: nltk.app.concordance_app
   :members:
   :undoc-members:
   :show-inheritance:
