nltk.corpus.reader.xmldocs module
=================================

.. automodule:: nltk.corpus.reader.xmldocs
   :members:
   :undoc-members:
   :show-inheritance:
