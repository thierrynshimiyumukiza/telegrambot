nltk.corpus.reader.nombank module
=================================

.. automodule:: nltk.corpus.reader.nombank
   :members:
   :undoc-members:
   :show-inheritance:
