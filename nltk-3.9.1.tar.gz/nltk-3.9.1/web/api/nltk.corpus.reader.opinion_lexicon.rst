nltk.corpus.reader.opinion\_lexicon module
==========================================

.. automodule:: nltk.corpus.reader.opinion_lexicon
   :members:
   :undoc-members:
   :show-inheritance:
