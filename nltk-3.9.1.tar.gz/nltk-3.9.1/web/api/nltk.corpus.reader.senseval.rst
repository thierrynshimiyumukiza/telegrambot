nltk.corpus.reader.senseval module
==================================

.. automodule:: nltk.corpus.reader.senseval
   :members:
   :undoc-members:
   :show-inheritance:
