nltk.corpus.reader.twitter module
=================================

.. automodule:: nltk.corpus.reader.twitter
   :members:
   :undoc-members:
   :show-inheritance:
