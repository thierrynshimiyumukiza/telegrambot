nltk.corpus.reader.api module
=============================

.. automodule:: nltk.corpus.reader.api
   :members:
   :undoc-members:
   :show-inheritance:
