nltk.chat package
=================

Submodules
----------

.. toctree::
   :maxdepth: 4

   nltk.chat.eliza
   nltk.chat.iesha
   nltk.chat.rude
   nltk.chat.suntsu
   nltk.chat.util
   nltk.chat.zen

Module contents
---------------

.. automodule:: nltk.chat
   :members:
   :undoc-members:
   :show-inheritance:
