nltk.classify package
=====================

Submodules
----------

.. toctree::
   :maxdepth: 4

   nltk.classify.api
   nltk.classify.decisiontree
   nltk.classify.maxent
   nltk.classify.megam
   nltk.classify.naivebayes
   nltk.classify.positivenaivebayes
   nltk.classify.rte_classify
   nltk.classify.scikitlearn
   nltk.classify.senna
   nltk.classify.svm
   nltk.classify.tadm
   nltk.classify.textcat
   nltk.classify.util
   nltk.classify.weka

Module contents
---------------

.. automodule:: nltk.classify
   :members:
   :undoc-members:
   :show-inheritance:
