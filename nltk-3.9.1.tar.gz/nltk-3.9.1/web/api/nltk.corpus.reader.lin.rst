nltk.corpus.reader.lin module
=============================

.. automodule:: nltk.corpus.reader.lin
   :members:
   :undoc-members:
   :show-inheritance:
