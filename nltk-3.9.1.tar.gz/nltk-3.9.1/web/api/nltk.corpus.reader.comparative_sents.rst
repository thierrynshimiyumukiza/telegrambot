nltk.corpus.reader.comparative\_sents module
============================================

.. automodule:: nltk.corpus.reader.comparative_sents
   :members:
   :undoc-members:
   :show-inheritance:
