nltk.corpus.reader.knbc module
==============================

.. automodule:: nltk.corpus.reader.knbc
   :members:
   :undoc-members:
   :show-inheritance:
