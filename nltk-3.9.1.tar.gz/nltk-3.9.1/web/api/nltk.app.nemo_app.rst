nltk.app.nemo\_app module
=========================

.. automodule:: nltk.app.nemo_app
   :members:
   :undoc-members:
   :show-inheritance:
