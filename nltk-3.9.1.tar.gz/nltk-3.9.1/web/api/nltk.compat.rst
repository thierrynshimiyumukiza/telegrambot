nltk.compat module
==================

.. automodule:: nltk.compat
   :members:
   :undoc-members:
   :show-inheritance:
