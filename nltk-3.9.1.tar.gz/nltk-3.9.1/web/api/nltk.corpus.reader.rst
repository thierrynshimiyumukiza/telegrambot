nltk.corpus.reader package
==========================

Submodules
----------

.. toctree::
   :maxdepth: 4

   nltk.corpus.reader.aligned
   nltk.corpus.reader.api
   nltk.corpus.reader.bcp47
   nltk.corpus.reader.bnc
   nltk.corpus.reader.bracket_parse
   nltk.corpus.reader.categorized_sents
   nltk.corpus.reader.chasen
   nltk.corpus.reader.childes
   nltk.corpus.reader.chunked
   nltk.corpus.reader.cmudict
   nltk.corpus.reader.comparative_sents
   nltk.corpus.reader.conll
   nltk.corpus.reader.crubadan
   nltk.corpus.reader.dependency
   nltk.corpus.reader.framenet
   nltk.corpus.reader.ieer
   nltk.corpus.reader.indian
   nltk.corpus.reader.ipipan
   nltk.corpus.reader.knbc
   nltk.corpus.reader.lin
   nltk.corpus.reader.markdown
   nltk.corpus.reader.mte
   nltk.corpus.reader.nkjp
   nltk.corpus.reader.nombank
   nltk.corpus.reader.nps_chat
   nltk.corpus.reader.opinion_lexicon
   nltk.corpus.reader.panlex_lite
   nltk.corpus.reader.panlex_swadesh
   nltk.corpus.reader.pl196x
   nltk.corpus.reader.plaintext
   nltk.corpus.reader.ppattach
   nltk.corpus.reader.propbank
   nltk.corpus.reader.pros_cons
   nltk.corpus.reader.reviews
   nltk.corpus.reader.rte
   nltk.corpus.reader.semcor
   nltk.corpus.reader.senseval
   nltk.corpus.reader.sentiwordnet
   nltk.corpus.reader.sinica_treebank
   nltk.corpus.reader.string_category
   nltk.corpus.reader.switchboard
   nltk.corpus.reader.tagged
   nltk.corpus.reader.timit
   nltk.corpus.reader.toolbox
   nltk.corpus.reader.twitter
   nltk.corpus.reader.udhr
   nltk.corpus.reader.util
   nltk.corpus.reader.verbnet
   nltk.corpus.reader.wordlist
   nltk.corpus.reader.wordnet
   nltk.corpus.reader.xmldocs
   nltk.corpus.reader.ycoe

Module contents
---------------

.. automodule:: nltk.corpus.reader
   :members:
   :undoc-members:
   :show-inheritance:
