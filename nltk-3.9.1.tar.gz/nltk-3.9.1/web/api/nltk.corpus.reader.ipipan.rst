nltk.corpus.reader.ipipan module
================================

.. automodule:: nltk.corpus.reader.ipipan
   :members:
   :undoc-members:
   :show-inheritance:
