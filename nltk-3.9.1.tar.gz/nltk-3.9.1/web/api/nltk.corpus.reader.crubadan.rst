nltk.corpus.reader.crubadan module
==================================

.. automodule:: nltk.corpus.reader.crubadan
   :members:
   :undoc-members:
   :show-inheritance:
