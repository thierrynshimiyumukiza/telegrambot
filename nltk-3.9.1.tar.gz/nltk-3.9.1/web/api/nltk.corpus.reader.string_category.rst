nltk.corpus.reader.string\_category module
==========================================

.. automodule:: nltk.corpus.reader.string_category
   :members:
   :undoc-members:
   :show-inheritance:
