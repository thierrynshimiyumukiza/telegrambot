nltk.corpus.reader.dependency module
====================================

.. automodule:: nltk.corpus.reader.dependency
   :members:
   :undoc-members:
   :show-inheritance:
