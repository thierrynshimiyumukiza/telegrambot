nltk.corpus.reader.indian module
================================

.. automodule:: nltk.corpus.reader.indian
   :members:
   :undoc-members:
   :show-inheritance:
