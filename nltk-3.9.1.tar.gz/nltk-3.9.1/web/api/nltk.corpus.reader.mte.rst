nltk.corpus.reader.mte module
=============================

.. automodule:: nltk.corpus.reader.mte
   :members:
   :undoc-members:
   :show-inheritance:
