nltk.classify.api module
========================

.. automodule:: nltk.classify.api
   :members:
   :undoc-members:
   :show-inheritance:
