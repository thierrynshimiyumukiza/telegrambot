nltk.corpus.reader.verbnet module
=================================

.. automodule:: nltk.corpus.reader.verbnet
   :members:
   :undoc-members:
   :show-inheritance:
