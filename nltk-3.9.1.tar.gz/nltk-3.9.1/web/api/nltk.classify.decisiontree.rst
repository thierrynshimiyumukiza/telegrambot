nltk.classify.decisiontree module
=================================

.. automodule:: nltk.classify.decisiontree
   :members:
   :undoc-members:
   :show-inheritance:
