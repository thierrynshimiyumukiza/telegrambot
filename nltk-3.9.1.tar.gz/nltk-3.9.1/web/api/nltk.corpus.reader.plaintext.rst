nltk.corpus.reader.plaintext module
===================================

.. automodule:: nltk.corpus.reader.plaintext
   :members:
   :undoc-members:
   :show-inheritance:
