nltk.corpus.reader.aligned module
=================================

.. automodule:: nltk.corpus.reader.aligned
   :members:
   :undoc-members:
   :show-inheritance:
