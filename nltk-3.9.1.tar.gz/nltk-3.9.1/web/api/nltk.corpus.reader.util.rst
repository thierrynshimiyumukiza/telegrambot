nltk.corpus.reader.util module
==============================

.. automodule:: nltk.corpus.reader.util
   :members:
   :undoc-members:
   :show-inheritance:
