nltk.corpus.reader.wordnet module
=================================

.. automodule:: nltk.corpus.reader.wordnet
   :members:
   :undoc-members:
   :show-inheritance:
