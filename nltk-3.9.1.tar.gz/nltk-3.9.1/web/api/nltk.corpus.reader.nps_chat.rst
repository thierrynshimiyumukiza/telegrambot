nltk.corpus.reader.nps\_chat module
===================================

.. automodule:: nltk.corpus.reader.nps_chat
   :members:
   :undoc-members:
   :show-inheritance:
