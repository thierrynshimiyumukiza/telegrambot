nltk.corpus.reader.pl196x module
================================

.. automodule:: nltk.corpus.reader.pl196x
   :members:
   :undoc-members:
   :show-inheritance:
