nltk.app.srparser\_app module
=============================

.. automodule:: nltk.app.srparser_app
   :members:
   :undoc-members:
   :show-inheritance:
