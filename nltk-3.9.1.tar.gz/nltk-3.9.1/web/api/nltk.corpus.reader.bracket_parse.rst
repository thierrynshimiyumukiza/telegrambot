nltk.corpus.reader.bracket\_parse module
========================================

.. automodule:: nltk.corpus.reader.bracket_parse
   :members:
   :undoc-members:
   :show-inheritance:
