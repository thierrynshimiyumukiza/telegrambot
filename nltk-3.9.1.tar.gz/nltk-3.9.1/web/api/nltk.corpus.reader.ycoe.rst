nltk.corpus.reader.ycoe module
==============================

.. automodule:: nltk.corpus.reader.ycoe
   :members:
   :undoc-members:
   :show-inheritance:
