nltk.corpus.reader.ppattach module
==================================

.. automodule:: nltk.corpus.reader.ppattach
   :members:
   :undoc-members:
   :show-inheritance:
