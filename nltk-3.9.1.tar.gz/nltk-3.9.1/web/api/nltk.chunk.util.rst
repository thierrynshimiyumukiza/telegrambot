nltk.chunk.util module
======================

.. automodule:: nltk.chunk.util
   :members:
   :undoc-members:
   :show-inheritance:
