nltk.collocations module
========================

.. automodule:: nltk.collocations
   :members:
   :undoc-members:
   :show-inheritance:
