nltk.corpus.reader.panlex\_swadesh module
=========================================

.. automodule:: nltk.corpus.reader.panlex_swadesh
   :members:
   :undoc-members:
   :show-inheritance:
