nltk.corpus.reader.udhr module
==============================

.. automodule:: nltk.corpus.reader.udhr
   :members:
   :undoc-members:
   :show-inheritance:
