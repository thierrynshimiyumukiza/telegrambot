nltk.corpus.reader.semcor module
================================

.. automodule:: nltk.corpus.reader.semcor
   :members:
   :undoc-members:
   :show-inheritance:
