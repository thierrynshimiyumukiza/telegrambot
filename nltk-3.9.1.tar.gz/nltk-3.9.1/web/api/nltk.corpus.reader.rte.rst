nltk.corpus.reader.rte module
=============================

.. automodule:: nltk.corpus.reader.rte
   :members:
   :undoc-members:
   :show-inheritance:
