nltk.corpus.reader.timit module
===============================

.. automodule:: nltk.corpus.reader.timit
   :members:
   :undoc-members:
   :show-inheritance:
