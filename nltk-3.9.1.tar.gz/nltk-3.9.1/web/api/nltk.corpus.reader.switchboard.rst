nltk.corpus.reader.switchboard module
=====================================

.. automodule:: nltk.corpus.reader.switchboard
   :members:
   :undoc-members:
   :show-inheritance:
