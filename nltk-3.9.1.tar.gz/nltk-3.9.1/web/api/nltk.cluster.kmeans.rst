nltk.cluster.kmeans module
==========================

.. automodule:: nltk.cluster.kmeans
   :members:
   :undoc-members:
   :show-inheritance:
