nltk.corpus.reader.panlex\_lite module
======================================

.. automodule:: nltk.corpus.reader.panlex_lite
   :members:
   :undoc-members:
   :show-inheritance:
