nltk.corpus.reader.bcp47 module
===============================

.. automodule:: nltk.corpus.reader.bcp47
   :members:
   :undoc-members:
   :show-inheritance:
