nltk.classify.senna module
==========================

.. automodule:: nltk.classify.senna
   :members:
   :undoc-members:
   :show-inheritance:
