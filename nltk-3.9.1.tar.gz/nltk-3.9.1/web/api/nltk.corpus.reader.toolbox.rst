nltk.corpus.reader.toolbox module
=================================

.. automodule:: nltk.corpus.reader.toolbox
   :members:
   :undoc-members:
   :show-inheritance:
