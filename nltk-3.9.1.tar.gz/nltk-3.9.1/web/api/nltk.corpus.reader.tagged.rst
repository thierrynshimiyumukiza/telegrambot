nltk.corpus.reader.tagged module
================================

.. automodule:: nltk.corpus.reader.tagged
   :members:
   :undoc-members:
   :show-inheritance:
