nltk.ccg package
================

Submodules
----------

.. toctree::
   :maxdepth: 4

   nltk.ccg.api
   nltk.ccg.chart
   nltk.ccg.combinator
   nltk.ccg.lexicon
   nltk.ccg.logic

Module contents
---------------

.. automodule:: nltk.ccg
   :members:
   :undoc-members:
   :show-inheritance:
