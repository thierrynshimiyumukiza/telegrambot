nltk.corpus.reader.markdown module
==================================

.. automodule:: nltk.corpus.reader.markdown
   :members:
   :undoc-members:
   :show-inheritance:
