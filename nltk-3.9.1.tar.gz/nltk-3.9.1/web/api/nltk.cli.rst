nltk.cli module
===============

.. automodule:: nltk.cli
   :members:
   :undoc-members:
   :show-inheritance:
