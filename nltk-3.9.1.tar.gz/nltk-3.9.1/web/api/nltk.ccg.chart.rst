nltk.ccg.chart module
=====================

.. automodule:: nltk.ccg.chart
   :members:
   :undoc-members:
   :show-inheritance:
