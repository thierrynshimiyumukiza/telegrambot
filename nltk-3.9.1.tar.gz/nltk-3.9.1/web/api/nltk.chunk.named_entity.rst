nltk.chunk.named\_entity module
===============================

.. automodule:: nltk.chunk.named_entity
   :members:
   :undoc-members:
   :show-inheritance:
