nltk.corpus.reader.framenet module
==================================

.. automodule:: nltk.corpus.reader.framenet
   :members:
   :undoc-members:
   :show-inheritance:
