nltk.corpus.reader.bnc module
=============================

.. automodule:: nltk.corpus.reader.bnc
   :members:
   :undoc-members:
   :show-inheritance:
