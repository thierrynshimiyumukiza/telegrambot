nltk.corpus.reader.propbank module
==================================

.. automodule:: nltk.corpus.reader.propbank
   :members:
   :undoc-members:
   :show-inheritance:
