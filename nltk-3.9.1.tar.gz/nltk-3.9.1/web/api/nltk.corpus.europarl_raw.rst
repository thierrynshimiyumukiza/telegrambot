nltk.corpus.europarl\_raw module
================================

.. automodule:: nltk.corpus.europarl_raw
   :members:
   :undoc-members:
   :show-inheritance:
