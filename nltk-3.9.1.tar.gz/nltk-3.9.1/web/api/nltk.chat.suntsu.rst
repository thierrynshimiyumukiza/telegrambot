nltk.chat.suntsu module
=======================

.. automodule:: nltk.chat.suntsu
   :members:
   :undoc-members:
   :show-inheritance:
