nltk.corpus.reader.reviews module
=================================

.. automodule:: nltk.corpus.reader.reviews
   :members:
   :undoc-members:
   :show-inheritance:
