nltk.corpus.reader.cmudict module
=================================

.. automodule:: nltk.corpus.reader.cmudict
   :members:
   :undoc-members:
   :show-inheritance:
