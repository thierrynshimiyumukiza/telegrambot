nltk.corpus.reader.pros\_cons module
====================================

.. automodule:: nltk.corpus.reader.pros_cons
   :members:
   :undoc-members:
   :show-inheritance:
