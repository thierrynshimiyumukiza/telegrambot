nltk.corpus.reader.chunked module
=================================

.. automodule:: nltk.corpus.reader.chunked
   :members:
   :undoc-members:
   :show-inheritance:
