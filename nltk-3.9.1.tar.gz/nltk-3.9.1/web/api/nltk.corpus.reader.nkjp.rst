nltk.corpus.reader.nkjp module
==============================

.. automodule:: nltk.corpus.reader.nkjp
   :members:
   :undoc-members:
   :show-inheritance:
