nltk.corpus.reader.childes module
=================================

.. automodule:: nltk.corpus.reader.childes
   :members:
   :undoc-members:
   :show-inheritance:
