nltk.corpus.reader.conll module
===============================

.. automodule:: nltk.corpus.reader.conll
   :members:
   :undoc-members:
   :show-inheritance:
