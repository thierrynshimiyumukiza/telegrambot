nltk.corpus.reader.sentiwordnet module
======================================

.. automodule:: nltk.corpus.reader.sentiwordnet
   :members:
   :undoc-members:
   :show-inheritance:
