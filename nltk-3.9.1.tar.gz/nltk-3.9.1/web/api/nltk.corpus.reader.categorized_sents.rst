nltk.corpus.reader.categorized\_sents module
============================================

.. automodule:: nltk.corpus.reader.categorized_sents
   :members:
   :undoc-members:
   :show-inheritance:
